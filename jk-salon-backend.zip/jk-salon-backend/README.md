# JK SALON — Backend (Supabase)

Is folder me JK Salon website ka poora backend hai: database, security, booking logic, admin panel.

## Folder kaisa hai

```
jk-salon-backend/
├── supabase/
│   ├── setup.sql          ← SABSE ZAROORI: poora database ek file me (SQL Editor me paste karein)
│   ├── make_admin.sql     ← apne email ko admin banane ke liye
│   ├── config.toml        ← sirf Supabase CLI wale ke liye (optional)
│   └── migrations/        ← wahi SQL 3 hisso me (CLI use karein to ye)
└── website/
    ├── index.html         ← aapki website (backend se juda hua)
    ├── js/config.js       ← yahan apni Supabase URL + anon key daalni hai
    ├── js/jk-backend.js   ← website <-> database connector
    └── admin/index.html   ← admin panel (bookings, prices, reviews, gallery, settings)
```

## Setup — 6 step (10 minute)

1. **supabase.com** par naya project banayein (region: Mumbai / South Asia).
2. Dashboard → **SQL Editor** → New query → `supabase/setup.sql` poori paste karein → **Run**.
   (Isse tables, security, booking logic, storage bucket aur 9 services ka data ban jayega.)
3. Dashboard → **Authentication → Users → Add user**: apna email + strong password (Auto Confirm ON).
4. `supabase/make_admin.sql` me email badlein → SQL Editor me Run. (Ab ye email admin hai.)
5. Dashboard → **Project Settings → API**: `Project URL` aur `anon public` key copy karke `website/js/config.js` me daalein.
6. **Authentication → Sign In / Providers → "Allow new users to sign up" OFF** karein (security ke liye).

Phir `website/` folder ko kisi bhi hosting par daal dein (Netlify / Vercel / Cloudflare Pages / GitHub Pages).
Admin panel: `https://aapki-site.com/admin/`

> ⚠️ `service_role` key kabhi website me ya config.js me na daalein. Sirf `anon` key.

## Ye kya-kya karta hai

**Customer side (website)**
- Services, prices, gallery, reviews ab database se aate hain. Admin me badlo → website par badal jata hai.
- Date chunte hi us din ke **free time slots** dikhte hain; bhare hue slots "Full" dikhte hain.
- Form submit par booking **database me save** hoti hai, phir WhatsApp khulta hai (Booking ID ke saath).
- Agar Supabase down / config nahi hai to website purane tareeke (sirf WhatsApp) se chalti rehti hai.

**Admin panel**
- Aaj ki bookings, pending, upcoming, mahine ki kamai (completed bookings se).
- Booking ka status badlo (pending → confirmed → completed / cancelled / no-show), customer ko WhatsApp bhejo.
- Services ke price / time / on-off, naya service jodo.
- Reviews approve (publish) ya delete.
- Gallery me photo upload / URL se add.
- Settings: phone, WhatsApp, timing, slot length, chairs (ek time par kitne customers), weekly off (jaise Sunday band).

## Security (kaise safe hai)

- Customer **bookings table ko seedha nahi padh sakta** — sirf `create_booking()` function se booking bana sakta hai. Matlab kisi ka phone number koi nahi nikal sakta.
- Double booking nahi hoti: ek slot par `chairs` (default 2) se zyada booking nahi, race condition se bhi bachav.
- Ek phone se max 3 upcoming bookings (spam rokne ke liye).
- Naye reviews apne aap publish nahi hote, admin approve karta hai.
- Admin ke alawa koi price / settings / gallery nahi badal sakta (RLS).
- Admin panel me har text escape hota hai (XSS se bachav).

## Zaroori cheezein jo aapko badalni hain

- **Address** — abhi placeholder hai ("Your Salon Address Line 1…"). Admin → Settings me daalein.
  (Website ke contact section ka address aur Instagram/YouTube links abhi `index.html` me static hain — wahan edit karein.)
- **Starter reviews** (Rahul, Aman, Sahil) website ke demo reviews the. Asli reviews aane par admin se delete kar dein.
- **Gallery/service photos** abhi Unsplash ki hain. Apne salon ki photos admin → Gallery se upload karein.

## Test kiya gaya

SQL ko asli PostgreSQL 16 par chalakar check kiya: booking banti hai, 3rd customer ko same slot par "fully booked" milta hai, galat phone / purani date / galat time / unknown service reject hote hain, anon user bookings nahi padh sakta, non-admin price nahi badal sakta, admin sab kar sakta hai, booking me price ka snapshot rehta hai (baad me price badle to purani booking ka price nahi badalta).
Supabase ka asli hosted project (Auth + Storage) yahan se test nahi ho sakta, isliye pehli baar setup ke baad ek test booking zaroor karke dekhein.

## Booking ke baad (optional next step)

Agar chahiye ki naya booking aate hi owner ko WhatsApp/Email apne-aap aaye, to Supabase **Database Webhook** + Edge Function se ho sakta hai — bol dena, bana dunga.
