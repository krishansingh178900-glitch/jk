-- JK SALON — COMPLETE SETUP (Supabase SQL Editor me poori file paste karke Run karein)


-- >>>>>>>>>> 20261111000000_init_schema.sql
-- =====================================================================
-- JK SALON — 1/3 : TABLES, TYPES, INDEXES, TRIGGERS
-- Run order: 20261111000000 -> 20261111000100 -> 20261111000200
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------- Enum ----------
do $$ begin
  create type public.booking_status as enum
    ('pending', 'confirmed', 'completed', 'cancelled', 'no_show');
exception when duplicate_object then null; end $$;

-- ---------- Shared trigger: updated_at ----------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ---------- site_settings (single row) ----------
create table if not exists public.site_settings (
  id               smallint primary key default 1 check (id = 1),
  salon_name       text      not null default 'JK SALON',
  phone            text      not null default '9351211025',
  whatsapp         text      not null default '919351211025',   -- country code + number
  address          text,
  open_time        time      not null default '10:00',
  close_time       time      not null default '21:00',          -- last slot start (inclusive)
  slot_minutes     int       not null default 60 check (slot_minutes between 15 and 240),
  chairs           int       not null default 2  check (chairs >= 1),   -- parallel bookings per slot
  max_advance_days int       not null default 30 check (max_advance_days between 1 and 365),
  weekly_off       smallint[] not null default '{}',            -- 0=Sunday ... 6=Saturday
  updated_at       timestamptz not null default now()
);
create trigger trg_site_settings_updated before update on public.site_settings
  for each row execute function public.set_updated_at();

-- ---------- services ----------
create table if not exists public.services (
  id           uuid primary key default gen_random_uuid(),
  slug         text not null unique,
  name         text not null check (char_length(name) between 2 and 80),
  description  text,
  price_inr    int  not null check (price_inr >= 0),
  duration_min int  not null check (duration_min > 0),
  image_url    text,
  is_active    boolean not null default true,
  sort_order   int not null default 0,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create trigger trg_services_updated before update on public.services
  for each row execute function public.set_updated_at();

-- ---------- bookings ----------
create table if not exists public.bookings (
  id             uuid primary key default gen_random_uuid(),
  customer_name  text not null check (char_length(customer_name) between 2 and 80),
  customer_phone text not null check (customer_phone ~ '^[6-9][0-9]{9}$'),
  service_id     uuid references public.services(id) on delete set null,
  service_name   text not null,             -- snapshot (service rename/delete ke baad bhi history rahe)
  price_inr      int  not null,             -- snapshot
  booking_date   date not null,
  booking_time   time not null,
  status         public.booking_status not null default 'pending',
  notes          text check (notes is null or char_length(notes) <= 300),
  source         text not null default 'website',
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists idx_bookings_slot  on public.bookings (booking_date, booking_time);
create index if not exists idx_bookings_phone on public.bookings (customer_phone);
create index if not exists idx_bookings_status on public.bookings (status);
create trigger trg_bookings_updated before update on public.bookings
  for each row execute function public.set_updated_at();

-- ---------- reviews ----------
create table if not exists public.reviews (
  id           uuid primary key default gen_random_uuid(),
  author_name  text not null check (char_length(author_name) between 2 and 60),
  author_tag   text check (author_tag is null or char_length(author_tag) <= 40),
  rating       smallint not null check (rating between 1 and 5),
  comment      text not null check (char_length(comment) between 10 and 600),
  is_published boolean not null default false,   -- admin approve karega
  created_at   timestamptz not null default now()
);
create index if not exists idx_reviews_published on public.reviews (is_published, created_at desc);

-- ---------- gallery_images ----------
create table if not exists public.gallery_images (
  id         uuid primary key default gen_random_uuid(),
  image_url  text not null,
  caption    text,
  is_active  boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

-- ---------- admins ----------
create table if not exists public.admins (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

-- >>>>>>>>>> 20261111000100_functions_rls.sql
-- =====================================================================
-- JK SALON — 2/3 : FUNCTIONS (booking logic), RLS, STORAGE
-- =====================================================================

-- ---------- helpers ----------
create or replace function public.is_admin()
returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

create or replace function public.salon_now()
returns timestamp
language sql stable as $$
  select (now() at time zone 'Asia/Kolkata')::timestamp;
$$;

-- ---------- 1) Available slots for a date (public) ----------
-- returns: slot_time, remaining chairs, is_available
create or replace function public.get_available_slots(p_date date)
returns table (slot_time time, remaining int, is_available boolean)
language plpgsql stable security definer set search_path = public as $$
declare
  s public.site_settings;
  t time;
  taken int;
  now_ist timestamp := public.salon_now();
begin
  select * into s from public.site_settings where id = 1;

  -- band din / past / bahut aage ki date => koi slot nahi
  if p_date < now_ist::date
     or p_date > now_ist::date + s.max_advance_days
     or extract(dow from p_date)::smallint = any (s.weekly_off) then
    return;
  end if;

  t := s.open_time;
  while t <= s.close_time loop
    select count(*) into taken
    from public.bookings b
    where b.booking_date = p_date
      and b.booking_time = t
      and b.status in ('pending', 'confirmed');

    slot_time    := t;
    remaining    := greatest(s.chairs - taken, 0);
    is_available := remaining > 0 and (p_date + t) > now_ist;
    return next;

    t := t + make_interval(mins => s.slot_minutes);
    exit when t < s.open_time;  -- midnight wrap guard
  end loop;
end $$;

-- ---------- 2) Create booking (public, safe) ----------
create or replace function public.create_booking(
  p_name    text,
  p_phone   text,
  p_service text,            -- service name ya slug
  p_date    date,
  p_time    time,
  p_notes   text default null
)
returns table (id uuid, service_name text, price_inr int,
               booking_date date, booking_time time, status public.booking_status)
language plpgsql security definer set search_path = public as $$
#variable_conflict use_column
declare
  s        public.site_settings;
  svc      public.services;
  v_phone  text := regexp_replace(coalesce(p_phone, ''), '\D', '', 'g');
  v_name   text := btrim(coalesce(p_name, ''));
  now_ist  timestamp := public.salon_now();
  taken    int;
  active_n int;
  slot_ok  boolean := false;
  t        time;
  new_row  public.bookings;
begin
  -- phone normalise: +91 / 91 / 0 prefix hatao
  if char_length(v_phone) = 12 and left(v_phone, 2) = '91' then v_phone := right(v_phone, 10); end if;
  if char_length(v_phone) = 11 and left(v_phone, 1) = '0'  then v_phone := right(v_phone, 10); end if;

  if char_length(v_name) < 2 or char_length(v_name) > 80 then
    raise exception 'Please enter a valid name.' using errcode = 'P0001';
  end if;
  if v_phone !~ '^[6-9][0-9]{9}$' then
    raise exception 'Please enter a valid 10-digit mobile number.' using errcode = 'P0001';
  end if;

  select * into s from public.site_settings where id = 1;

  select * into svc from public.services sv
   where sv.is_active and (lower(sv.name) = lower(btrim(p_service)) or sv.slug = lower(btrim(p_service)))
   limit 1;
  if not found then
    raise exception 'Selected service is not available.' using errcode = 'P0001';
  end if;

  if p_date is null or p_time is null then
    raise exception 'Date and time are required.' using errcode = 'P0001';
  end if;
  if p_date < now_ist::date then
    raise exception 'Please choose today or a future date.' using errcode = 'P0001';
  end if;
  if p_date > now_ist::date + s.max_advance_days then
    raise exception 'Please choose a date within the next % days.', s.max_advance_days using errcode = 'P0001';
  end if;
  if extract(dow from p_date)::smallint = any (s.weekly_off) then
    raise exception 'Salon is closed on the selected day.' using errcode = 'P0001';
  end if;

  -- time valid slot hona chahiye
  t := s.open_time;
  while t <= s.close_time loop
    if t = p_time then slot_ok := true; exit; end if;
    t := t + make_interval(mins => s.slot_minutes);
    exit when t < s.open_time;
  end loop;
  if not slot_ok then
    raise exception 'Invalid time slot.' using errcode = 'P0001';
  end if;
  if (p_date + p_time) <= now_ist then
    raise exception 'This time has already passed. Please choose a later slot.' using errcode = 'P0001';
  end if;

  -- same slot par ek saath do requests race na karein
  perform pg_advisory_xact_lock(hashtext('slot:' || p_date::text || p_time::text));

  select count(*) into taken from public.bookings b
   where b.booking_date = p_date and b.booking_time = p_time
     and b.status in ('pending', 'confirmed');
  if taken >= s.chairs then
    raise exception 'This slot is fully booked. Please choose another time.' using errcode = 'P0001';
  end if;

  -- spam guard: ek phone se max 3 upcoming active bookings
  select count(*) into active_n from public.bookings b
   where b.customer_phone = v_phone
     and b.status in ('pending', 'confirmed')
     and b.booking_date >= now_ist::date;
  if active_n >= 3 then
    raise exception 'You already have 3 upcoming bookings. Please call the salon.' using errcode = 'P0001';
  end if;

  insert into public.bookings
    (customer_name, customer_phone, service_id, service_name, price_inr,
     booking_date, booking_time, notes)
  values
    (v_name, v_phone, svc.id, svc.name, svc.price_inr,
     p_date, p_time, nullif(left(btrim(coalesce(p_notes, '')), 300), ''))
  returning * into new_row;

  return query
    select new_row.id, new_row.service_name, new_row.price_inr,
           new_row.booking_date, new_row.booking_time, new_row.status;
end $$;

-- ---------- 3) Admin dashboard stats ----------
create or replace function public.admin_dashboard_stats()
returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  d date := public.salon_now()::date;
  res jsonb;
begin
  if not public.is_admin() then
    raise exception 'Not authorized' using errcode = '42501';
  end if;

  select jsonb_build_object(
    'today_total',     count(*) filter (where booking_date = d and status <> 'cancelled'),
    'today_pending',   count(*) filter (where booking_date = d and status = 'pending'),
    'upcoming',        count(*) filter (where booking_date >= d and status in ('pending','confirmed')),
    'month_completed', count(*) filter (where status = 'completed'
                         and date_trunc('month', booking_date) = date_trunc('month', d)),
    'month_revenue',   coalesce(sum(price_inr) filter (where status = 'completed'
                         and date_trunc('month', booking_date) = date_trunc('month', d)), 0)
  ) into res
  from public.bookings;

  return res;
end $$;

-- ---------- 4) Public site data in one call ----------
create or replace function public.get_site_data()
returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'settings', (select to_jsonb(s) - 'updated_at' from public.site_settings s where id = 1),
    'services', coalesce((select jsonb_agg(to_jsonb(v) order by v.sort_order)
                  from (select id, slug, name, description, price_inr, duration_min, image_url, sort_order
                        from public.services where is_active) v), '[]'::jsonb),
    'gallery',  coalesce((select jsonb_agg(to_jsonb(g) order by g.sort_order)
                  from (select id, image_url, caption, sort_order
                        from public.gallery_images where is_active) g), '[]'::jsonb),
    'reviews',  coalesce((select jsonb_agg(to_jsonb(r) order by r.created_at desc)
                  from (select id, author_name, author_tag, rating, comment, created_at
                        from public.reviews where is_published
                        order by created_at desc limit 12) r), '[]'::jsonb)
  );
$$;

-- =====================================================================
-- ROW LEVEL SECURITY
-- =====================================================================
alter table public.site_settings  enable row level security;
alter table public.services       enable row level security;
alter table public.bookings       enable row level security;
alter table public.reviews        enable row level security;
alter table public.gallery_images enable row level security;
alter table public.admins         enable row level security;

-- site_settings: sab padh sakte hain, sirf admin badal sakta hai
create policy "settings read"   on public.site_settings for select using (true);
create policy "settings update" on public.site_settings for update using (public.is_admin()) with check (public.is_admin());

-- services
create policy "services public read" on public.services for select using (is_active or public.is_admin());
create policy "services admin write"  on public.services for all    using (public.is_admin()) with check (public.is_admin());

-- gallery
create policy "gallery public read" on public.gallery_images for select using (is_active or public.is_admin());
create policy "gallery admin write" on public.gallery_images for all    using (public.is_admin()) with check (public.is_admin());

-- reviews: public sirf published padhe; koi bhi naya review bhej sakta hai (unpublished)
create policy "reviews public read"   on public.reviews for select using (is_published or public.is_admin());
create policy "reviews public insert" on public.reviews for insert
  with check (is_published = false);
create policy "reviews admin update"  on public.reviews for update using (public.is_admin()) with check (public.is_admin());
create policy "reviews admin delete"  on public.reviews for delete using (public.is_admin());

-- bookings: public ke liye koi direct access nahi (sirf create_booking() RPC se)
create policy "bookings admin all" on public.bookings for all using (public.is_admin()) with check (public.is_admin());

-- admins: sirf admin apni list dekh sakta hai; insert sirf SQL editor se
create policy "admins read self" on public.admins for select using (user_id = auth.uid());

-- =====================================================================
-- GRANTS
-- =====================================================================
revoke all on public.bookings from anon, authenticated;
grant select, insert, update, delete on public.bookings to authenticated;  -- RLS admin tak seemit karti hai

grant usage on schema public to anon, authenticated;
grant select on public.site_settings, public.services, public.gallery_images, public.reviews to anon, authenticated;
grant insert on public.reviews to anon, authenticated;
grant update on public.site_settings to authenticated;
grant insert, update, delete on public.services, public.gallery_images to authenticated;
grant update, delete on public.reviews to authenticated;
grant select on public.admins to authenticated;

grant execute on function public.get_available_slots(date)                         to anon, authenticated;
grant execute on function public.create_booking(text,text,text,date,time,text)     to anon, authenticated;
grant execute on function public.get_site_data()                                   to anon, authenticated;
grant execute on function public.admin_dashboard_stats()                           to authenticated;
grant execute on function public.is_admin()                                        to anon, authenticated;

-- =====================================================================
-- STORAGE: public bucket for gallery / service photos
-- =====================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('salon-media', 'salon-media', true, 5242880,
        array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "media public read"  on storage.objects for select using (bucket_id = 'salon-media');
create policy "media admin insert" on storage.objects for insert with check (bucket_id = 'salon-media' and public.is_admin());
create policy "media admin update" on storage.objects for update using (bucket_id = 'salon-media' and public.is_admin());
create policy "media admin delete" on storage.objects for delete using (bucket_id = 'salon-media' and public.is_admin());

-- >>>>>>>>>> 20261111000200_seed.sql
-- =====================================================================
-- JK SALON — 3/3 : SEED DATA (website ke hisaab se)
-- =====================================================================

insert into public.site_settings (id, salon_name, phone, whatsapp, address, open_time, close_time, slot_minutes, chairs, weekly_off)
values (1, 'JK SALON', '9351211025', '919351211025',
        'Your Salon Address Line 1, City, State - Pincode',
        '10:00', '21:00', 60, 2, '{}')
on conflict (id) do nothing;

insert into public.services (slug, name, description, price_inr, duration_min, image_url, sort_order) values
('haircut',           'Haircut',           'Precision cuts tailored to your face shape, hair texture and personal style.',            199,  30,  'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=700&q=80', 1),
('hair-styling',      'Hair Styling',      'Event-ready styling — from sleek and formal to textured and modern.',                     299,  25,  'https://images.unsplash.com/photo-1622286342621-4bd786c2447c?auto=format&fit=crop&w=700&q=80', 2),
('hair-wash',         'Hair Wash',         'A refreshing cleanse with premium shampoo and a soothing scalp massage.',                 149,  20,  'https://images.unsplash.com/photo-1580618672591-eb180b1a973f?auto=format&fit=crop&w=700&q=80', 3),
('beard-trimming',    'Beard Trimming',    'Sharp lines, clean edges and a perfectly sculpted beard you''ll love.',                    99,   20,  'https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=700&q=80', 4),
('hair-colour',       'Hair Colour',       'Global colour, highlights or grey coverage using ammonia-free products.',                 499,  60,  'https://images.unsplash.com/photo-1512690459411-b9245aed614b?auto=format&fit=crop&w=700&q=80', 5),
('hair-spa',          'Hair Spa',          'Deep-conditioning therapy that repairs, nourishes and strengthens hair.',                 599,  45,  'https://images.unsplash.com/photo-1596728325488-58c87691e9af?auto=format&fit=crop&w=700&q=80', 6),
('facial',            'Facial',            'Deep-cleansing facial that removes impurities and revives tired skin.',                   699,  50,  'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=700&q=80', 7),
('head-massage',      'Head Massage',      'Traditional pressure-point massage with warm oil to melt away stress.',                   249,  25,  'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=700&q=80', 8),
('grooming-packages', 'Grooming Packages', 'Haircut + beard + facial + head massage — the complete transformation.',                  1499, 120, 'https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?auto=format&fit=crop&w=700&q=80', 9)
on conflict (slug) do nothing;

insert into public.gallery_images (image_url, caption, sort_order) values
('https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=1000&q=80', 'Precision Haircut', 1),
('https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=700&q=80',  'Beard Sculpting',   2),
('https://images.unsplash.com/photo-1521490683712-35a1cb235d1c?auto=format&fit=crop&w=700&q=80',  'Classic Shave',     3),
('https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?auto=format&fit=crop&w=700&q=80',  'The Studio',        4),
('https://images.unsplash.com/photo-1517832606299-7ae9b720a186?auto=format&fit=crop&w=700&q=80',  'Premium Tools',     5),
('https://images.unsplash.com/photo-1633681926022-84c23e8cb2d6?auto=format&fit=crop&w=1100&q=80', 'Inside JK Salon',   6),
('https://images.unsplash.com/photo-1596728325488-58c87691e9af?auto=format&fit=crop&w=700&q=80',  'Hair Treatment',    7),
('https://images.unsplash.com/photo-1503443207922-dff7d543fd0e?auto=format&fit=crop&w=700&q=80',  'The Finish',        8);

-- Starter reviews (website par pehle se the). Real reviews aane par inhe admin panel se hata dein.
insert into public.reviews (author_name, author_tag, rating, comment, is_published) values
('Rahul Sharma', 'Regular Client',     5, 'Best haircut I''ve had in years. The stylist actually listened to what I wanted and the finish was perfect. The salon is spotless and the vibe is really premium.', true),
('Aman Verma',   'Grooming Package',   5, 'Took the grooming package before my wedding and honestly it was worth every rupee. Facial, head massage, beard styling — everything was top class. Highly recommended.', true),
('Sahil Khan',   'Beard & Haircut',    5, 'Booking on WhatsApp took me 30 seconds and they were ready when I arrived. Clean tools, great music, and my beard has never looked this sharp. My new regular spot.', true);
