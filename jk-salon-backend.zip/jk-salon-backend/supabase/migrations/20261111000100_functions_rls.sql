-- =====================================================================
-- JK SALON — 2/3 : FUNCTIONS (booking logic), RLS, STORAGE
-- =====================================================================

-- ---------- helpers ----------
create or replace function public.is_admin()
returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

create or replace function public.salon_now()
returns timestamp
language sql stable as $$
  select (now() at time zone 'Asia/Kolkata')::timestamp;
$$;

-- ---------- 1) Available slots for a date (public) ----------
-- returns: slot_time, remaining chairs, is_available
create or replace function public.get_available_slots(p_date date)
returns table (slot_time time, remaining int, is_available boolean)
language plpgsql stable security definer set search_path = public as $$
declare
  s public.site_settings;
  t time;
  taken int;
  now_ist timestamp := public.salon_now();
begin
  select * into s from public.site_settings where id = 1;

  -- band din / past / bahut aage ki date => koi slot nahi
  if p_date < now_ist::date
     or p_date > now_ist::date + s.max_advance_days
     or extract(dow from p_date)::smallint = any (s.weekly_off) then
    return;
  end if;

  t := s.open_time;
  while t <= s.close_time loop
    select count(*) into taken
    from public.bookings b
    where b.booking_date = p_date
      and b.booking_time = t
      and b.status in ('pending', 'confirmed');

    slot_time    := t;
    remaining    := greatest(s.chairs - taken, 0);
    is_available := remaining > 0 and (p_date + t) > now_ist;
    return next;

    t := t + make_interval(mins => s.slot_minutes);
    exit when t < s.open_time;  -- midnight wrap guard
  end loop;
end $$;

-- ---------- 2) Create booking (public, safe) ----------
create or replace function public.create_booking(
  p_name    text,
  p_phone   text,
  p_service text,            -- service name ya slug
  p_date    date,
  p_time    time,
  p_notes   text default null
)
returns table (id uuid, service_name text, price_inr int,
               booking_date date, booking_time time, status public.booking_status)
language plpgsql security definer set search_path = public as $$
#variable_conflict use_column
declare
  s        public.site_settings;
  svc      public.services;
  v_phone  text := regexp_replace(coalesce(p_phone, ''), '\D', '', 'g');
  v_name   text := btrim(coalesce(p_name, ''));
  now_ist  timestamp := public.salon_now();
  taken    int;
  active_n int;
  slot_ok  boolean := false;
  t        time;
  new_row  public.bookings;
begin
  -- phone normalise: +91 / 91 / 0 prefix hatao
  if char_length(v_phone) = 12 and left(v_phone, 2) = '91' then v_phone := right(v_phone, 10); end if;
  if char_length(v_phone) = 11 and left(v_phone, 1) = '0'  then v_phone := right(v_phone, 10); end if;

  if char_length(v_name) < 2 or char_length(v_name) > 80 then
    raise exception 'Please enter a valid name.' using errcode = 'P0001';
  end if;
  if v_phone !~ '^[6-9][0-9]{9}$' then
    raise exception 'Please enter a valid 10-digit mobile number.' using errcode = 'P0001';
  end if;

  select * into s from public.site_settings where id = 1;

  select * into svc from public.services sv
   where sv.is_active and (lower(sv.name) = lower(btrim(p_service)) or sv.slug = lower(btrim(p_service)))
   limit 1;
  if not found then
    raise exception 'Selected service is not available.' using errcode = 'P0001';
  end if;

  if p_date is null or p_time is null then
    raise exception 'Date and time are required.' using errcode = 'P0001';
  end if;
  if p_date < now_ist::date then
    raise exception 'Please choose today or a future date.' using errcode = 'P0001';
  end if;
  if p_date > now_ist::date + s.max_advance_days then
    raise exception 'Please choose a date within the next % days.', s.max_advance_days using errcode = 'P0001';
  end if;
  if extract(dow from p_date)::smallint = any (s.weekly_off) then
    raise exception 'Salon is closed on the selected day.' using errcode = 'P0001';
  end if;

  -- time valid slot hona chahiye
  t := s.open_time;
  while t <= s.close_time loop
    if t = p_time then slot_ok := true; exit; end if;
    t := t + make_interval(mins => s.slot_minutes);
    exit when t < s.open_time;
  end loop;
  if not slot_ok then
    raise exception 'Invalid time slot.' using errcode = 'P0001';
  end if;
  if (p_date + p_time) <= now_ist then
    raise exception 'This time has already passed. Please choose a later slot.' using errcode = 'P0001';
  end if;

  -- same slot par ek saath do requests race na karein
  perform pg_advisory_xact_lock(hashtext('slot:' || p_date::text || p_time::text));

  select count(*) into taken from public.bookings b
   where b.booking_date = p_date and b.booking_time = p_time
     and b.status in ('pending', 'confirmed');
  if taken >= s.chairs then
    raise exception 'This slot is fully booked. Please choose another time.' using errcode = 'P0001';
  end if;

  -- spam guard: ek phone se max 3 upcoming active bookings
  select count(*) into active_n from public.bookings b
   where b.customer_phone = v_phone
     and b.status in ('pending', 'confirmed')
     and b.booking_date >= now_ist::date;
  if active_n >= 3 then
    raise exception 'You already have 3 upcoming bookings. Please call the salon.' using errcode = 'P0001';
  end if;

  insert into public.bookings
    (customer_name, customer_phone, service_id, service_name, price_inr,
     booking_date, booking_time, notes)
  values
    (v_name, v_phone, svc.id, svc.name, svc.price_inr,
     p_date, p_time, nullif(left(btrim(coalesce(p_notes, '')), 300), ''))
  returning * into new_row;

  return query
    select new_row.id, new_row.service_name, new_row.price_inr,
           new_row.booking_date, new_row.booking_time, new_row.status;
end $$;

-- ---------- 3) Admin dashboard stats ----------
create or replace function public.admin_dashboard_stats()
returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  d date := public.salon_now()::date;
  res jsonb;
begin
  if not public.is_admin() then
    raise exception 'Not authorized' using errcode = '42501';
  end if;

  select jsonb_build_object(
    'today_total',     count(*) filter (where booking_date = d and status <> 'cancelled'),
    'today_pending',   count(*) filter (where booking_date = d and status = 'pending'),
    'upcoming',        count(*) filter (where booking_date >= d and status in ('pending','confirmed')),
    'month_completed', count(*) filter (where status = 'completed'
                         and date_trunc('month', booking_date) = date_trunc('month', d)),
    'month_revenue',   coalesce(sum(price_inr) filter (where status = 'completed'
                         and date_trunc('month', booking_date) = date_trunc('month', d)), 0)
  ) into res
  from public.bookings;

  return res;
end $$;

-- ---------- 4) Public site data in one call ----------
create or replace function public.get_site_data()
returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'settings', (select to_jsonb(s) - 'updated_at' from public.site_settings s where id = 1),
    'services', coalesce((select jsonb_agg(to_jsonb(v) order by v.sort_order)
                  from (select id, slug, name, description, price_inr, duration_min, image_url, sort_order
                        from public.services where is_active) v), '[]'::jsonb),
    'gallery',  coalesce((select jsonb_agg(to_jsonb(g) order by g.sort_order)
                  from (select id, image_url, caption, sort_order
                        from public.gallery_images where is_active) g), '[]'::jsonb),
    'reviews',  coalesce((select jsonb_agg(to_jsonb(r) order by r.created_at desc)
                  from (select id, author_name, author_tag, rating, comment, created_at
                        from public.reviews where is_published
                        order by created_at desc limit 12) r), '[]'::jsonb)
  );
$$;

-- =====================================================================
-- ROW LEVEL SECURITY
-- =====================================================================
alter table public.site_settings  enable row level security;
alter table public.services       enable row level security;
alter table public.bookings       enable row level security;
alter table public.reviews        enable row level security;
alter table public.gallery_images enable row level security;
alter table public.admins         enable row level security;

-- site_settings: sab padh sakte hain, sirf admin badal sakta hai
create policy "settings read"   on public.site_settings for select using (true);
create policy "settings update" on public.site_settings for update using (public.is_admin()) with check (public.is_admin());

-- services
create policy "services public read" on public.services for select using (is_active or public.is_admin());
create policy "services admin write"  on public.services for all    using (public.is_admin()) with check (public.is_admin());

-- gallery
create policy "gallery public read" on public.gallery_images for select using (is_active or public.is_admin());
create policy "gallery admin write" on public.gallery_images for all    using (public.is_admin()) with check (public.is_admin());

-- reviews: public sirf published padhe; koi bhi naya review bhej sakta hai (unpublished)
create policy "reviews public read"   on public.reviews for select using (is_published or public.is_admin());
create policy "reviews public insert" on public.reviews for insert
  with check (is_published = false);
create policy "reviews admin update"  on public.reviews for update using (public.is_admin()) with check (public.is_admin());
create policy "reviews admin delete"  on public.reviews for delete using (public.is_admin());

-- bookings: public ke liye koi direct access nahi (sirf create_booking() RPC se)
create policy "bookings admin all" on public.bookings for all using (public.is_admin()) with check (public.is_admin());

-- admins: sirf admin apni list dekh sakta hai; insert sirf SQL editor se
create policy "admins read self" on public.admins for select using (user_id = auth.uid());

-- =====================================================================
-- GRANTS
-- =====================================================================
revoke all on public.bookings from anon, authenticated;
grant select, insert, update, delete on public.bookings to authenticated;  -- RLS admin tak seemit karti hai

grant usage on schema public to anon, authenticated;
grant select on public.site_settings, public.services, public.gallery_images, public.reviews to anon, authenticated;
grant insert on public.reviews to anon, authenticated;
grant update on public.site_settings to authenticated;
grant insert, update, delete on public.services, public.gallery_images to authenticated;
grant update, delete on public.reviews to authenticated;
grant select on public.admins to authenticated;

grant execute on function public.get_available_slots(date)                         to anon, authenticated;
grant execute on function public.create_booking(text,text,text,date,time,text)     to anon, authenticated;
grant execute on function public.get_site_data()                                   to anon, authenticated;
grant execute on function public.admin_dashboard_stats()                           to authenticated;
grant execute on function public.is_admin()                                        to anon, authenticated;

-- =====================================================================
-- STORAGE: public bucket for gallery / service photos
-- =====================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('salon-media', 'salon-media', true, 5242880,
        array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "media public read"  on storage.objects for select using (bucket_id = 'salon-media');
create policy "media admin insert" on storage.objects for insert with check (bucket_id = 'salon-media' and public.is_admin());
create policy "media admin update" on storage.objects for update using (bucket_id = 'salon-media' and public.is_admin());
create policy "media admin delete" on storage.objects for delete using (bucket_id = 'salon-media' and public.is_admin());
