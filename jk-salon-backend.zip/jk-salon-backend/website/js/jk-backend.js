/* =====================================================================
   JK SALON — js/jk-backend.js
   Website <-> Supabase connector.
   - Services, gallery, reviews database se load karta hai
   - Date chunne par live available time slots dikhata hai
   - Booking database me save karta hai (create_booking RPC)
   Agar Supabase configure nahi hai ya down hai, to website purane
   (sirf WhatsApp wale) tareeke se chalti rehti hai.
   ===================================================================== */
(function () {
  'use strict';

  var cfg = window.JK_CONFIG || {};
  var ready = !!(window.supabase && cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY &&
                 cfg.SUPABASE_URL.indexOf('YOUR-PROJECT') === -1);
  var sb = ready ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;

  var $  = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  // XSS se bachne ke liye har DB text escape hota hai
  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function safeUrl(u) { return /^https:\/\//i.test(u || '') ? u : ''; }

  function fmtTime(t) {                    // "13:00:00" -> "01:00 PM"
    var p = String(t).split(':'), h = parseInt(p[0], 10), m = p[1] || '00';
    var ap = h >= 12 ? 'PM' : 'AM';
    h = h % 12; if (h === 0) h = 12;
    return (h < 10 ? '0' : '') + h + ':' + m + ' ' + ap;
  }
  function to24(str) {                     // "01:00 PM" -> "13:00"  (static fallback options)
    var m = /^(\d{1,2}):(\d{2})\s*(AM|PM)$/i.exec(String(str).trim());
    if (!m) return str;
    var h = parseInt(m[1], 10) % 12;
    if (m[3].toUpperCase() === 'PM') h += 12;
    return (h < 10 ? '0' : '') + h + ':' + m[2];
  }

  var STAR = '<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2 3 6.6 7.2.9-5.3 4.9 1.4 7.1L12 18l-6.3 3.5 1.4-7.1L1.8 9.5 9 8.6z"/></svg>';
  var ZOOM = '<span class="zoom-ico" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/></svg></span>';

  /* ---------------- public API used by index.html ---------------- */
  window.JKBackend = {
    enabled: ready,
    whatsapp: null,

    createBooking: function (p) {
      return sb.rpc('create_booking', {
        p_name:    p.name,
        p_phone:   p.phone,
        p_service: p.service,
        p_date:    p.date,
        p_time:    to24(p.time),
        p_notes:   p.notes || null
      }).then(function (r) {
        if (r.error) {
          var err = new Error(r.error.code === 'P0001' ? r.error.message
                    : 'Booking could not be saved. Please try again or call us.');
          throw err;
        }
        return Array.isArray(r.data) ? r.data[0] : r.data;
      });
    },

    refreshSlots: function () { loadSlots(); }
  };

  if (!ready) return;

  /* ---------------- render: services ---------------- */
  function renderServices(list) {
    var grid = $('.services-grid');
    if (grid && list.length) {
      grid.innerHTML = list.map(function (s, i) {
        return '<article class="service-card reveal in">' +
          '<div class="service-media">' +
            '<img src="' + esc(safeUrl(s.image_url)) + '" alt="' + esc(s.name) + ' at JK Salon" loading="lazy" width="700" height="480">' +
            '<span class="service-price">₹' + esc(s.price_inr) + '</span>' +
          '</div>' +
          '<div class="service-body"><h3>' + esc(s.name) + '</h3><p>' + esc(s.description) + '</p>' +
            '<div class="service-foot"><span class="service-time">' + esc(s.duration_min) + ' min</span>' +
            '<button class="link-btn" data-service="' + esc(s.name) + '">Book Now →</button></div>' +
          '</div></article>';
      }).join('');
    }

    var sel = $('#service');
    if (sel && list.length) {
      var keep = sel.value;
      sel.innerHTML = '<option value="" disabled>Choose a service…</option>' +
        list.map(function (s) {
          return '<option value="' + esc(s.name) + '">' + esc(s.name) + ' — ₹' + esc(s.price_inr) + '</option>';
        }).join('');
      sel.value = keep || '';
      if (!sel.value) sel.selectedIndex = 0;
    }
  }

  /* ---------------- render: gallery ---------------- */
  function renderGallery(list) {
    var grid = $('#galleryGrid');
    if (!grid || !list.length) return;
    grid.innerHTML = list.map(function (g) {
      return '<figure class="gallery-item reveal reveal-zoom in">' +
        '<img src="' + esc(safeUrl(g.image_url)) + '" alt="' + esc(g.caption || 'JK Salon') + '" loading="lazy" width="900" height="700">' +
        ZOOM + '<figcaption class="gallery-cap">' + esc(g.caption || '') + '</figcaption></figure>';
    }).join('');
  }

  /* ---------------- render: reviews ---------------- */
  function renderReviews(list) {
    var grid = $('.reviews-grid');
    if (!grid || !list.length) return;
    grid.innerHTML = list.map(function (r) {
      var n = Math.max(1, Math.min(5, r.rating | 0));
      var stars = new Array(n + 1).join(STAR);
      return '<article class="review-card reveal in">' +
        '<span class="review-quote" aria-hidden="true">&ldquo;</span>' +
        '<div class="stars" aria-label="Rated ' + n + ' out of 5">' + stars + '</div>' +
        '<p>' + esc(r.comment) + '</p>' +
        '<div class="review-author"><span class="avatar" aria-hidden="true">' +
          esc((r.author_name || '?').charAt(0).toUpperCase()) + '</span><div><strong>' + esc(r.author_name) +
          '</strong><small>' + esc(r.author_tag || 'Client') + '</small></div></div></article>';
    }).join('');
  }

  /* ---------------- lightbox for re-rendered gallery (event delegation) ---------------- */
  document.addEventListener('click', function (e) {
    var item = e.target.closest && e.target.closest('#galleryGrid .gallery-item');
    if (item) {
      var img = $('img', item), lb = $('#lightbox'), lbImg = $('#lightboxImg');
      if (img && lb && lbImg) {
        lbImg.src = img.src; lbImg.alt = img.alt;
        lb.classList.add('open'); document.body.style.overflow = 'hidden';
      }
      return;
    }
    // "Book Now" buttons on re-rendered service cards
    var btn = e.target.closest && e.target.closest('[data-service]');
    if (btn) {
      var sel = $('#service'), val = btn.getAttribute('data-service');
      if (sel) {
        $$('option', sel).forEach(function (o) { if (o.value === val) sel.value = val; });
        var f = sel.closest('.field'); if (f) f.classList.remove('invalid');
      }
      var b = document.getElementById('booking');
      if (b) b.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });

  /* ---------------- live time slots ---------------- */
  var dateEl = $('#prefDate'), timeEl = $('#prefTime');
  var slotReq = 0;

  function setTimeOptions(html) {
    if (timeEl) { timeEl.innerHTML = html; timeEl.selectedIndex = 0; }
  }

  function loadSlots() {
    if (!dateEl || !timeEl || !dateEl.value) return;
    var my = ++slotReq;
    setTimeOptions('<option value="" disabled selected>Loading slots…</option>');

    sb.rpc('get_available_slots', { p_date: dateEl.value }).then(function (r) {
      if (my !== slotReq) return;                       // purana response ignore
      if (r.error) {                                    // fallback: static list
        setTimeOptions('<option value="" disabled selected>Choose a time…</option>' +
          ['10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00']
            .map(function (t) { return '<option value="' + t + '">' + fmtTime(t + ':00') + '</option>'; }).join(''));
        return;
      }
      var rows = r.data || [];
      if (!rows.length) {
        setTimeOptions('<option value="" disabled selected>No slots on this date</option>');
        return;
      }
      setTimeOptions('<option value="" disabled selected>Choose a time…</option>' +
        rows.map(function (s) {
          var v = String(s.slot_time).slice(0, 5);
          return '<option value="' + v + '"' + (s.is_available ? '' : ' disabled') + '>' +
                 fmtTime(s.slot_time) + (s.is_available ? '' : ' — Full') + '</option>';
        }).join(''));
    });
  }
  if (dateEl) dateEl.addEventListener('change', loadSlots);

  /* ---------------- initial data load ---------------- */
  sb.rpc('get_site_data').then(function (r) {
    if (r.error || !r.data) return;
    var d = r.data;
    if (d.settings && d.settings.whatsapp) window.JKBackend.whatsapp = d.settings.whatsapp;
    renderServices(d.services || []);
    renderGallery(d.gallery || []);
    renderReviews(d.reviews || []);
  });
})();
