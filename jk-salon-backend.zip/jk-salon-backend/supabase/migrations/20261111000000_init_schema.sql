-- =====================================================================
-- JK SALON — 1/3 : TABLES, TYPES, INDEXES, TRIGGERS
-- Run order: 20261111000000 -> 20261111000100 -> 20261111000200
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------- Enum ----------
do $$ begin
  create type public.booking_status as enum
    ('pending', 'confirmed', 'completed', 'cancelled', 'no_show');
exception when duplicate_object then null; end $$;

-- ---------- Shared trigger: updated_at ----------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ---------- site_settings (single row) ----------
create table if not exists public.site_settings (
  id               smallint primary key default 1 check (id = 1),
  salon_name       text      not null default 'JK SALON',
  phone            text      not null default '9351211025',
  whatsapp         text      not null default '919351211025',   -- country code + number
  address          text,
  open_time        time      not null default '10:00',
  close_time       time      not null default '21:00',          -- last slot start (inclusive)
  slot_minutes     int       not null default 60 check (slot_minutes between 15 and 240),
  chairs           int       not null default 2  check (chairs >= 1),   -- parallel bookings per slot
  max_advance_days int       not null default 30 check (max_advance_days between 1 and 365),
  weekly_off       smallint[] not null default '{}',            -- 0=Sunday ... 6=Saturday
  updated_at       timestamptz not null default now()
);
create trigger trg_site_settings_updated before update on public.site_settings
  for each row execute function public.set_updated_at();

-- ---------- services ----------
create table if not exists public.services (
  id           uuid primary key default gen_random_uuid(),
  slug         text not null unique,
  name         text not null check (char_length(name) between 2 and 80),
  description  text,
  price_inr    int  not null check (price_inr >= 0),
  duration_min int  not null check (duration_min > 0),
  image_url    text,
  is_active    boolean not null default true,
  sort_order   int not null default 0,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create trigger trg_services_updated before update on public.services
  for each row execute function public.set_updated_at();

-- ---------- bookings ----------
create table if not exists public.bookings (
  id             uuid primary key default gen_random_uuid(),
  customer_name  text not null check (char_length(customer_name) between 2 and 80),
  customer_phone text not null check (customer_phone ~ '^[6-9][0-9]{9}$'),
  service_id     uuid references public.services(id) on delete set null,
  service_name   text not null,             -- snapshot (service rename/delete ke baad bhi history rahe)
  price_inr      int  not null,             -- snapshot
  booking_date   date not null,
  booking_time   time not null,
  status         public.booking_status not null default 'pending',
  notes          text check (notes is null or char_length(notes) <= 300),
  source         text not null default 'website',
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists idx_bookings_slot  on public.bookings (booking_date, booking_time);
create index if not exists idx_bookings_phone on public.bookings (customer_phone);
create index if not exists idx_bookings_status on public.bookings (status);
create trigger trg_bookings_updated before update on public.bookings
  for each row execute function public.set_updated_at();

-- ---------- reviews ----------
create table if not exists public.reviews (
  id           uuid primary key default gen_random_uuid(),
  author_name  text not null check (char_length(author_name) between 2 and 60),
  author_tag   text check (author_tag is null or char_length(author_tag) <= 40),
  rating       smallint not null check (rating between 1 and 5),
  comment      text not null check (char_length(comment) between 10 and 600),
  is_published boolean not null default false,   -- admin approve karega
  created_at   timestamptz not null default now()
);
create index if not exists idx_reviews_published on public.reviews (is_published, created_at desc);

-- ---------- gallery_images ----------
create table if not exists public.gallery_images (
  id         uuid primary key default gen_random_uuid(),
  image_url  text not null,
  caption    text,
  is_active  boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

-- ---------- admins ----------
create table if not exists public.admins (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
