-- =====================================================================
-- ADMIN BANANE KE LIYE (migrations ke BAAD, ek baar chalayein)
-- Step 1: Supabase Dashboard -> Authentication -> Users -> "Add user"
--         apna email + strong password daalein ("Auto Confirm User" ON)
-- Step 2: Niche EMAIL badal kar SQL Editor me Run karein
-- =====================================================================
insert into public.admins (user_id)
select id from auth.users where email = 'YOUR-EMAIL@example.com'
on conflict do nothing;

-- Check: 1 row aani chahiye
select a.user_id, u.email from public.admins a join auth.users u on u.id = a.user_id;
