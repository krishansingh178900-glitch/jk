-- =====================================================================
-- JK SALON — 3/3 : SEED DATA (website ke hisaab se)
-- =====================================================================

insert into public.site_settings (id, salon_name, phone, whatsapp, address, open_time, close_time, slot_minutes, chairs, weekly_off)
values (1, 'JK SALON', '9351211025', '919351211025',
        'Your Salon Address Line 1, City, State - Pincode',
        '10:00', '21:00', 60, 2, '{}')
on conflict (id) do nothing;

insert into public.services (slug, name, description, price_inr, duration_min, image_url, sort_order) values
('haircut',           'Haircut',           'Precision cuts tailored to your face shape, hair texture and personal style.',            199,  30,  'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=700&q=80', 1),
('hair-styling',      'Hair Styling',      'Event-ready styling — from sleek and formal to textured and modern.',                     299,  25,  'https://images.unsplash.com/photo-1622286342621-4bd786c2447c?auto=format&fit=crop&w=700&q=80', 2),
('hair-wash',         'Hair Wash',         'A refreshing cleanse with premium shampoo and a soothing scalp massage.',                 149,  20,  'https://images.unsplash.com/photo-1580618672591-eb180b1a973f?auto=format&fit=crop&w=700&q=80', 3),
('beard-trimming',    'Beard Trimming',    'Sharp lines, clean edges and a perfectly sculpted beard you''ll love.',                    99,   20,  'https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=700&q=80', 4),
('hair-colour',       'Hair Colour',       'Global colour, highlights or grey coverage using ammonia-free products.',                 499,  60,  'https://images.unsplash.com/photo-1512690459411-b9245aed614b?auto=format&fit=crop&w=700&q=80', 5),
('hair-spa',          'Hair Spa',          'Deep-conditioning therapy that repairs, nourishes and strengthens hair.',                 599,  45,  'https://images.unsplash.com/photo-1596728325488-58c87691e9af?auto=format&fit=crop&w=700&q=80', 6),
('facial',            'Facial',            'Deep-cleansing facial that removes impurities and revives tired skin.',                   699,  50,  'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=700&q=80', 7),
('head-massage',      'Head Massage',      'Traditional pressure-point massage with warm oil to melt away stress.',                   249,  25,  'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=700&q=80', 8),
('grooming-packages', 'Grooming Packages', 'Haircut + beard + facial + head massage — the complete transformation.',                  1499, 120, 'https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?auto=format&fit=crop&w=700&q=80', 9)
on conflict (slug) do nothing;

insert into public.gallery_images (image_url, caption, sort_order) values
('https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=1000&q=80', 'Precision Haircut', 1),
('https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=700&q=80',  'Beard Sculpting',   2),
('https://images.unsplash.com/photo-1521490683712-35a1cb235d1c?auto=format&fit=crop&w=700&q=80',  'Classic Shave',     3),
('https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?auto=format&fit=crop&w=700&q=80',  'The Studio',        4),
('https://images.unsplash.com/photo-1517832606299-7ae9b720a186?auto=format&fit=crop&w=700&q=80',  'Premium Tools',     5),
('https://images.unsplash.com/photo-1633681926022-84c23e8cb2d6?auto=format&fit=crop&w=1100&q=80', 'Inside JK Salon',   6),
('https://images.unsplash.com/photo-1596728325488-58c87691e9af?auto=format&fit=crop&w=700&q=80',  'Hair Treatment',    7),
('https://images.unsplash.com/photo-1503443207922-dff7d543fd0e?auto=format&fit=crop&w=700&q=80',  'The Finish',        8);

-- Starter reviews (website par pehle se the). Real reviews aane par inhe admin panel se hata dein.
insert into public.reviews (author_name, author_tag, rating, comment, is_published) values
('Rahul Sharma', 'Regular Client',     5, 'Best haircut I''ve had in years. The stylist actually listened to what I wanted and the finish was perfect. The salon is spotless and the vibe is really premium.', true),
('Aman Verma',   'Grooming Package',   5, 'Took the grooming package before my wedding and honestly it was worth every rupee. Facial, head massage, beard styling — everything was top class. Highly recommended.', true),
('Sahil Khan',   'Beard & Haircut',    5, 'Booking on WhatsApp took me 30 seconds and they were ready when I arrived. Clean tools, great music, and my beard has never looked this sharp. My new regular spot.', true);
