/* =====================================================================
   JK SALON — js/config.js
   Supabase Dashboard -> Project Settings -> API se ye 2 values copy karein.
   ANON KEY public hoti hai (browser me dikhna normal hai) — security RLS se hoti hai.
   ⚠️ service_role key yahan KABHI na daalein.
   ===================================================================== */
window.JK_CONFIG = {
  SUPABASE_URL:      'https://YOUR-PROJECT.supabase.co',
  SUPABASE_ANON_KEY: 'YOUR-ANON-PUBLIC-KEY'
};
